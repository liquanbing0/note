# coding=utf-8


class Mode(object):
    DISTRIBUTED = "Distributed"
    INTEGRATED = "Integrated"


class Role(object):
    MASTER = "Master"
    SLAVE = "Slave"
